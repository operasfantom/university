package numbers;

public class DoubleNumber implements AbstractNumber<DoubleNumber> {
    private double value;

    public DoubleNumber() {
        value = 0.0;
    }

    public DoubleNumber(double value) {
        this.value = value;
    }

    public DoubleNumber(Integer integer){
        this.value = integer.doubleValue();
    }

    @Override
    public DoubleNumber add(DoubleNumber rhs) {
        return new DoubleNumber(value + rhs.value);
    }

    @Override
    public DoubleNumber subtract(DoubleNumber rhs) {
        return new DoubleNumber(value - rhs.value);
    }

    @Override
    public DoubleNumber multiply(DoubleNumber rhs) {
        return new DoubleNumber(value * rhs.value);
    }

    @Override
    public DoubleNumber divide(DoubleNumber rhs) {
        return new DoubleNumber(value / rhs.value);
    }

    @Override
    public DoubleNumber negate() {
        return new DoubleNumber(-value);
    }

    @Override
    public DoubleNumber getValue() {
        return new DoubleNumber(value);
    }

    @Override
    public String reader(String s, int i) {
        return null;
    }
}
