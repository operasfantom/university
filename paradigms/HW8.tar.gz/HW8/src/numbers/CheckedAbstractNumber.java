package numbers;

public interface CheckedAbstractNumber<T> {
    T checkedAdd(T rhs);

    T checkedSubtract(T rhs);

    T checkedMultiply(T rhs);

    T checkedDivide(T rhs);

    T checkedNegate();
}
