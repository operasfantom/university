package numbers;

public interface AbstractNumber<T> {

    T add(T rhs);

    T subtract(T rhs);

    T multiply(T rhs);

    T divide(T rhs);

    T negate();

    T getValue();

    String reader(String s, int i);
}
