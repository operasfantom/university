package numbers;

import java.math.BigInteger;

public class BigIntegerNumber implements AbstractNumber<BigIntegerNumber> {
    private BigInteger value;


    public BigIntegerNumber() {
        value = BigInteger.valueOf(0);
    }

    public BigIntegerNumber(BigInteger value) {
        this.value = value;
    }

    public BigIntegerNumber(Integer integer) {
        value = BigInteger.valueOf(integer);
    }

    @Override
    public BigIntegerNumber add(BigIntegerNumber rhs) {
        return new BigIntegerNumber(value.add(rhs.value));
    }

    @Override
    public BigIntegerNumber subtract(BigIntegerNumber rhs) {
        return null;
    }

    @Override
    public BigIntegerNumber multiply(BigIntegerNumber rhs) {
        return null;
    }

    @Override
    public BigIntegerNumber divide(BigIntegerNumber rhs) {
        return null;
    }

    @Override
    public BigIntegerNumber negate() {
        return null;
    }

    @Override
    public BigIntegerNumber getValue() {
        return null;
    }

    @Override
    public String reader(String s, int i) {
        return null;
    }
}
