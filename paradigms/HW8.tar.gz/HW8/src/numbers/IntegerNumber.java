package numbers;

public class IntegerNumber implements AbstractNumber<IntegerNumber>, CheckedAbstractNumber<IntegerNumber> {
    private int value;

    public IntegerNumber() {
        value = 0;
    }

    public IntegerNumber(int value) {
        this.value = value;
    }

    public IntegerNumber(Integer value) {
        this.value = value;
    }

    @Override
    public IntegerNumber add(IntegerNumber rhs) {
        return new IntegerNumber(this.value + rhs.value);
    }

    @Override
    public IntegerNumber subtract(IntegerNumber rhs) {
        return new IntegerNumber(this.value - rhs.value);
    }

    @Override
    public IntegerNumber multiply(IntegerNumber rhs) {
        return new IntegerNumber(this.value * rhs.value);
    }

    @Override
    public IntegerNumber divide(IntegerNumber rhs) {
        return new IntegerNumber(this.value / rhs.value);
    }

    @Override
    public IntegerNumber negate() {
        return new IntegerNumber(-value);
    }

    @Override
    public IntegerNumber checkedAdd(IntegerNumber rhs) {
        return null;
    }

    @Override
    public IntegerNumber checkedSubtract(IntegerNumber rhs) {
        return null;
    }

    @Override
    public IntegerNumber checkedMultiply(IntegerNumber rhs) {
        return null;
    }

    @Override
    public IntegerNumber checkedDivide(IntegerNumber rhs) {
        return null;
    }

    @Override
    public IntegerNumber checkedNegate() {
        return null;
    }

    @Override
    public IntegerNumber getValue() {
        return new IntegerNumber(value);
    }

    @Override
    public String reader(String s, int i) {
        StringBuilder sb = new StringBuilder();
        while (i < s.length() && Character.isDigit(s.charAt(i))) {
            sb.append(s.charAt(i));
            ++i;
        }
        return sb.toString();
    }
}
