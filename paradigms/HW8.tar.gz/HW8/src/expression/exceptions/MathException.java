package expression.exceptions;

public class MathException extends Exception {

    public MathException(String s) {
        super(s);
    }

}
