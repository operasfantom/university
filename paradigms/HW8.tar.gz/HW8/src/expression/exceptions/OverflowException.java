package expression.exceptions;

public class OverflowException extends Exception {

    public OverflowException(String s) {
        super(s);
    }

}
