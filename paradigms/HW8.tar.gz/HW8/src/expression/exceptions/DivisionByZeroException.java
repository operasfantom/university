package expression.exceptions;

public class DivisionByZeroException extends Exception {

    public DivisionByZeroException(String s) {
        super(s);
    }

}
