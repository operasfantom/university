package expression.checked;

import expression.AbstractOperation;
import expression.TripleExpression;
import expression.exceptions.DivisionByZeroException;
import expression.exceptions.MathException;
import expression.exceptions.OverflowException;
import numbers.AbstractNumber;

public class CheckedMultiply<T extends AbstractNumber<T>>  extends AbstractOperation<T> {
    public CheckedMultiply(TripleExpression x, TripleExpression y) {
        super(x, y);
    }

    @Override
    protected T calculate(T x0, T x1) throws OverflowException, DivisionByZeroException, MathException {
        return null;
    }

//    protected int calculate(int x0, int x1) throws OverflowException {
//        if (x0 == 0 || x1 == 0) {
//            return 0;
//        }
//        if (x0 > 0 && x1 > 0 && Integer.MAX_VALUE / x0 < x1) {
//            throw new OverflowException(x0 + "*" + x1 + "overflowed");
//        }
//        if (x0 < 0 && x1 < 0 && Integer.MAX_VALUE / x0 > x1) {
//            throw new OverflowException(x0 + "*" + x1 + "overflowed");
//        }
//        if (x0 > 0 && x1 < 0 && Integer.MIN_VALUE / x0 > x1) {
//            throw new OverflowException(x0 + "*" + x1 + "overflowed");
//        }
//        if (x0 < 0 && x1 > 0 && Integer.MIN_VALUE / x1 > x0) {
//            throw new OverflowException(x0 + "*" + x1 + "overflowed");
//        }
//        return x0 * x1;
//    }
}
