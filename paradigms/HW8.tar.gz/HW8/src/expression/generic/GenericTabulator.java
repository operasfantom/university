package expression.generic;

import expression.TripleExpression;
import expression.parser.ExpressionParser;
import numbers.AbstractNumber;
import numbers.BigIntegerNumber;
import numbers.DoubleNumber;
import numbers.IntegerNumber;

import java.math.BigInteger;
import java.util.function.Function;

public class GenericTabulator implements Tabulator {

    @Override
    public Object[][][] tabulate(String mode, String expression, int x1, int x2, int y1, int y2, int z1, int z2) throws Exception {
        TripleExpression<?> tripleExpression = null;
        ExpressionParser parser = new ExpressionParser();
        Function <Integer, AbstractNumber<?>> constructor = null;
        switch (mode) {
            case "i":
                tripleExpression = parser.parse(expression, new IntegerNumber());
                constructor = IntegerNumber::new;
                break;
            case "d":
                tripleExpression = parser.parse(expression, new DoubleNumber());
                constructor = DoubleNumber::new;
                break;
            case "bi":
                tripleExpression = parser.parse(expression, new BigIntegerNumber());
                constructor = BigIntegerNumber::new;
                break;
            case "u":
                break;
            case "l":
                break;
            case "s":
                break;
            default:
                throw new Exception("unknown mode: " + mode);
        }
        Object[][][] result = new Object[x2 - x1 + 1][y2 - y1 + 1][z2 - z1 + 1];
        for (int i = x1; i <= x2; i++) {
            for (int j = y1; j <= y2; j++) {
                for (int k = z1; k <= z2; k++) {
                    result[i - x1][j - y1][k - z1] = tripleExpression.evaluate(constructor.apply(i), constructor.apply(j), constructor.apply(k));
                }
            }
        }
        return result;
    }

    ///private <T extends AbstractNumber<T>>calculate
}
