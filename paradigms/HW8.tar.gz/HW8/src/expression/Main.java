package expression;

import expression.generic.GenericTabulator;

public class Main {
    public static void main(String[] args) throws Exception {
        GenericTabulator tabulator = new GenericTabulator();
        Object[][][] result = tabulator.tabulate("i", "x", 1, 1, 1, 1, 1, 1);
        System.out.println(result);
    }
}
